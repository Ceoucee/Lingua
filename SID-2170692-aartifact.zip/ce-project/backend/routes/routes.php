<?php
/*
path: routes/routes.php
this is the hub file for all the routes in the application

*/

//declearing routes array
 return [
    "register" => "AuthController@Register",
    "login" => "AuthController@Login",
    "logout" => "AuthController@Logout",
    "user" => "UserController@User",
    "languages" => "LanguageController@getallLanguages",
    "home" => "HomeController@Home",


 ];
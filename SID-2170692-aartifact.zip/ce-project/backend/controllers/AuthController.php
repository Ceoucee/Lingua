<?php
/*
path : controllers/AuthController.php
file that handles authentication
*/

//import validation middleware
require_once __DIR__ . '/../middleware/validationMiddleware.php';
require_once __DIR__ . '/../middleware/sanitizationMiddleware.php';
//import connection from db-connect.php
require_once __DIR__ . '/../utilities/db-connect.php';
//import composer packages
require_once __DIR__ . '/../vendor/autoload.php';

use \Firebase\JWT\JWT;








class AuthController {

    private $connection;

    public function __construct(mysqli $connection) {
        $this->connection = $connection;
    }

    public function Register () {
        //checking if request is a post reuest
        if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
            http_response_code(405); // Method Not Allowed
            echo json_encode(array("error" => "Method not allowed"));
            return;
        }

        $raw_data = file_get_contents("php://input");
        $data = json_decode($raw_data);
    
        if (!$data) {
            echo json_encode(["status" => "error", "message" => "Data is required"]);
            return;
        }

        //run validation middleware
        $required_fields = [ "name", "email", "password", "country"];
        $required_types = [
            "name' => 'string",
            "email" => "string",
            "password" => "string",
             "country" => "string",
         
        ];

        $errors = Validation::validateField($required_fields, $data);
        //$errors = array_merge($errors, Validation::validateType($required_types, $data));

        //check if there are any errors
        foreach ($errors as $error) {
            if (!empty($error)) {
                echo json_encode(["status" => "error", "message" => $error]);
                return;
            }
        }

        //check if email is valid   

        $email_error = Validation::validateEmail($data->email);
        if (!empty($email_error)) {
            echo json_encode(["status" => "error", "message" => $email_error]);
            return;
        }

        //check if password is valid
        $password_error = Validation::validatePassword($data->password);
        if (!empty($password_error)) {
            echo json_encode(["status" => "error", "message" => $password_error]);
            return;
        }

        //if email is valid, check if email already exists
        $email = $data->email;
        $email_exists = sanitizer::checkEmail($email, $this->connection);
        if ($email_exists) {
            echo json_encode(["status" => "error", "message" => "Email already exists"]);
            return;
        }

        //if all checks passed then register user
        $name = $data->name;
        $password = password_hash($data->password, PASSWORD_DEFAULT);
        $country = $data->country;
       

        $query = $this->connection->prepare("INSERT INTO users (username, email, password, country) VALUES (?, ?, ?, ?)");
        if (!$query) {
            http_response_code(500);
            $error = $this->connection->error;
            echo json_encode(["status" => "error", "message" => $error]);
            return;
        }
        $query->bind_param("ssss", $name, $email, $password, $country, );
        $query->execute();

        if ($query->affected_rows > 0) {
            http_response_code(201);
            echo json_encode(["status" => "success", "message" => "User registered successfully"]);
            return;
        } else {
            http_response_code(500);
            echo json_encode(["status" => "error", "message" => "User registration failed"]);
            return;
        }


        
        
    }

    /*
    section: login
    path: /api/auth/login
    */

    public function login () {
        //get raw data
        $raw_data = file_get_contents("php://input");
        $data = json_decode($raw_data);

        //checking data for email and password fields
        if (!isset($data->email) || !isset($data->password)) {
            http_response_code(400);
            echo json_encode(["status" => "error", "message" => "Email and password are required"]);
            return;
        }
            //check if email is valid
            $email_error = Validation::validateEmail($data->email);
            if (!empty($email_error)) {
                echo json_encode(["status" => "error", "message" => $email_error]);
                return;
            }

            //running login logic
            $email = $data->email;
            $password = $data->password;
            //check if email exists
            $query = $this->connection->prepare("SELECT * FROM users WHERE email = ?");
            if (!$query) {
                http_response_code(500);
                $error = $this->connection->error;
                echo json_encode(["status" => "error", "message" => $error]);
                return;
            }
            $query->bind_param("s", $email);
            $query->execute();
            $result = $query->get_result();
            if ($result->num_rows === 0) {
                http_response_code(404);     
                echo json_encode(["status" => "error", "message" => "User not found"]);
                return;
            }
            $user = $result->fetch_assoc();
            //check if password is correct by checking if hashed password matches the one in the database
            if (!password_verify($password, $user['password'])) {
                http_response_code(401);
                echo json_encode(["status" => "error", "message" => "Invalid password"]);
                return;
            }

            //if all checks passed, generate token and return it to the user
            //set the env variable for jwt secret
            $jwt_secret = "secret";
            $payload = [
                "id" => $user['id'],
                "email" => $user['email'],
                "country" => $user['country'],
                "iat" => time(),
                "exp" => time() + (60 * 60 * 24)
            ];
            
            $token = JWT::encode($payload, $jwt_secret, "HS256");
            echo json_encode(["status" => "success", "message" => "Login successful", "data" => $token]);
            return;




    }

 }
?>

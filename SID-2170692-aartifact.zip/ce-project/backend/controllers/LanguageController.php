<?php 
/**
 * LanguageController.php
 * controller for all language related routes
 
 */
//importing models
require_once __DIR__ . '/../models/language.php';
require_once __DIR__ . '/../utilities/db-connect.php';

class LanguageController {
    private $connection;

    public function __construct(mysqli $connection) {
        $this->connection = $connection;
    }

public function getallLanguages () {
    // check if request is a get request
    if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
        http_response_code(405); // Method Not Allowed
        echo json_encode(array("error" => "Method not allowed"));
        return;
    }
    $languageModel = new LanguageModel($this->connection);
    $languages = $languageModel->getAllLanguages();
    if (empty($languages)) {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "No languages found"]);
        return;
    }
    echo json_encode(["status" => "success", "data" => $languages]);
}
}


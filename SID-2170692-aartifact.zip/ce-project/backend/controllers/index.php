<?php
/*
path: controllers/index.php
this is the hub file for all the controllers in the application

*/

//making imports
require_once("AuthController.php");
require_once("UserController.php");
require_once ('LanguageController.php');






?>
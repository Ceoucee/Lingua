
<?php

/*
path : middleware/validationMiddleware.php
file thatll handle type validation and field validation
*/

class Validation {
    //public array where we store all the errors
    public $errors = [];

    public static function validateField ($requiredFields, $data) {
        $errors = [];
        foreach ($requiredFields as $field) {
            if (!isset($data->$field) || empty($data->$field)) {
                $errors[$field] = "The $field field is required";
                
            } else {
                $errors[$field] = "";
            }
        }
        return $errors;
    }

    public static function validateType ($requiredTypes, $data) {
        foreach ($requiredTypes as $field => $type) {
            if (gettype($data->$field) !== $type) {
                $errors[$field] = "The $field field must be of type $type";
            } else {
                $errors[$field] = "";
            }
        }
        return $errors;
    }
    
    public static function validateEmail ($email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            //log error to errors array
            return "Invalid email format";
        
        }
        return "";
    }

    public static function validatePassword ($password) {
        if (strlen($password) < 8) {
            return "Password must be at least 8 characters";
        }
        return "";
    }

    //


    }

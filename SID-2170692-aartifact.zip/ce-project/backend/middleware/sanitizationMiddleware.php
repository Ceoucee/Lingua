<?php
/**
 * middleware/sanitizationMiddleware.php
 * file that handles sanitization of user iunjputs
 */

 class sanitizer {
    public $issues = [];

    public static function sanitize ($data) {
        $sanitized_data = [];
        foreach ($data as $key => $value) {
            $sanitized_data[$key] = htmlspecialchars(strip_tags($value));
        }
        return $sanitized_data;
    }

    //check if mail already exists

    public static function checkEmail ($email, $connection) {
        $query = "SELECT * FROM users WHERE email = '$email'";
        $result = mysqli_query($connection, $query);
        if (mysqli_num_rows($result) > 0) {
            return true;
        }
        return false;
    }
      
    
 }

    
?>
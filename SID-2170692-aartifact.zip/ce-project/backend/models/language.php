<?php

/**
 * language.php
 * language model
 */

class LanguageModel {
    private $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    //check if language is supported

    public function checkLanguage ($language) {
        $query = "SELECT * FROM languages WHERE language = '$language'";
        $result = mysqli_query($this->connection, $query);
        if (mysqli_num_rows($result) > 0) {
            return true;
        }
        return false;
    }

    public function getAllLanguages () {
        $query = "SELECT * FROM languages";
        $result = mysqli_query($this->connection, $query);
        $languages = [];
        while ($row = mysqli_fetch_assoc($result)) {
            array_push($languages, $row);
        }
        return $languages;
    }

}
<?php
/*
path: models/user.php
file that handles all the user related database operations
*/

class Usermodel {
  
    private $connection;

    public function __construct($connection) {
        $this->connection = $connection;
    }

    public function getUserbyemail ($email) {
        $query = "SELECT * FROM users WHERE email = '$email'";
        $result = mysqli_query($this->connection, $query);
        if (mysqli_num_rows($result) > 0) {
            return mysqli_fetch_assoc($result);
        }
        return false;
    }

    }

?>
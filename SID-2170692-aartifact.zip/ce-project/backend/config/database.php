<?php
//config\database.php
//details for connecting to the database
return [
    "host" => "localhost",
    "username" => "root",
    "password" => "",
    "database" => "lingua"
]



?>
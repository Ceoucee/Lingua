<?php
// Set CORS headers
header("Access-Control-Allow-Origin: *"); // Allow requests from any origin
header("Access-Control-Allow-Methods: GET, POST, OPTIONS"); // Allow the HTTP methods you need
header("Access-Control-Allow-Headers: Content-Type"); // Allow specific headers

// Check for OPTIONS request (preflight)
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204); // No content
    exit();
}

/*
 index.php
    This is the main file for the application
    It is the first file that is loaded when the application is accessed
*/
//making import
include("utilities/db-connect.php");
require_once("controllers/index.php");
//importing routes
$routes = include("routes/routes.php");
//include the config file
$config = include("config/database.php");
$database = new Connector($config);
$connection = $database->connect();  

//handling thr request by routes
$routeURL = $_SERVER ["REQUEST_URI"];
$route = basename ($routeURL); // Remove leading and trailing slashes
if (!empty($route)){
    if (array_key_exists($route, $routes)) {
        $controller = $routes[$route];
        $controller = explode("@", $controller);
        $controllerName = $controller[0];
        $controllerMethod = $controller[1];
        $controller = new $controllerName($connection);   
        $controller->$controllerMethod();
    } else {
        http_response_code(404);
        echo json_encode(["status" => "error", "message" => "Route not found"]);

    }

} else {
    http_response_code(404);
    echo json_encode(["status" => "error", "message" => "Route not found"]);
}







?>
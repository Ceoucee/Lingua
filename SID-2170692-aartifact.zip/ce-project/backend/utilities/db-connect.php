<?php
/*
    * This file is used to connect to the database
    * It is included in all files that need to connect to the database
*/
 class Connector {
    private $config;

    public function __construct(array $config) {
        $this->config = $config;
    }

    public function connect() {
        $host = $this->config["host"];
        $username = $this->config["username"];
        $password = $this->config["password"];
        $database = $this->config["database"];

        $connection = mysqli_connect($host, $username, $password, $database);

        if (!$connection) {
            die("Connection failed: " . mysqli_connect_error());
        }

        return $connection;
    }
 }




?>
"use client";
import React from 'react'
import {useState, useEffect} from 'react'
import { useRouter } from 'next/navigation'

const RouteProtector:any= ({children}:{
    children: React.ReactNode
}) => {
    const router = useRouter()
    useEffect(() => {
        if(!localStorage.getItem('authToken')){
            router.push('/auth/login')
        } 

    }, [])
  return  <>{children}</>
}

export default RouteProtector
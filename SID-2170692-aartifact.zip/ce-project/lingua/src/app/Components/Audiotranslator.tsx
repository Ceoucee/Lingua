import {useState, useEffect, useRef} from 'react'
import axios from 'axios'


// ################################3
// translaor props
interface TranslatorProps {
  sub_key: string | any;
  serviceRegion: string | any;
}
// ################################

const Audiotranslator = () => {
  // *************************************
  // edge of file
  // *************************************

  // *************************************
  // declearing the state
  const [recordedBlobs, setRecordedBlobs] = useState<{ blob: Blob; timestamp: number }[]>([]);
  const [recording, setRecording] = useState<boolean>(false);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);

  // *************************************


  // *************************************
  // the functions

  //************************* */
  //start the recording function
  const startAudioCapture = async (): Promise<void> => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      const chunks: BlobPart[] = [];

      recorder.ondataavailable = (event) => {
        if (event.data.size > 0) {
          const recordedBlob = new Blob([event.data], { type: 'audio/wav' });
          // Handle the recordedBlob
          chunks.push(recordedBlob);
        }
      };
      recorder.onstop = async () => {
        console.log('recorder.onstop() called');
        const blob = new Blob(chunks, { type: 'audio/wav' });
        setRecordedBlobs((prevBlobs) => [...prevBlobs, { blob, timestamp: Date.now() }]);
        
      };

      recorder.start();
      console.log('recorder.state', recorder.state);
      setRecording(true);
      mediaRecorderRef.current = recorder;
    } catch (error) {
      console.error('Error starting audio capture:', error);
    }
  };
    //************************* */
  
  //************************* */
  //stop the recording function
  const stopAudioCapture = async (): Promise<void> => {
    if (mediaRecorderRef.current && recording) {
      mediaRecorderRef.current.stop();
      setRecording(false);
      const stream = mediaRecorderRef.current.stream;
      if (stream) {
        stream.getTracks().forEach(track => track.stop());
      }
    }
  };
  //************************* */
  // ************************* */
  // play the recording function
  const playMostRecentRecording = (): void => {
    if (recordedBlobs.length > 0) {
      const mostRecentBlob = recordedBlobs[recordedBlobs.length - 1].blob;
      const objectUrl = URL.createObjectURL(mostRecentBlob);

      if (audioRef.current) {
        audioRef.current.src = objectUrl;
        audioRef.current.play();
      }
    }
  };
  // ************************* */
  // tester function
  const functionTester = async (args:TranslatorProps) => {
    //testing the logic for the token generation and the transcribtion api call

  }
  
  const functionTest = () => {
    const args = {
      sub_key: process.env.NEXT_PUBLIC_KEY,
      serviceRegion: process.env.NEXT_PUBLIC_REGION,
    }
    console.log(args, "clicked");
   //get the token from the local storage 
    const token = localStorage.getItem('token');
    if (token) {
      console.log(token, "token");
    }
  }
  // ************************* */
  // ************************* */
  // transcribe the audio

const transcribeAudio = async (audioFile: Blob) => {
  const serviceRegion = process.env.NEXT_PUBLIC_REGION;
  const endPoint = `https://${serviceRegion}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language=en-US`;
  
}





  // *************************************
  return (

    <div className='flex flex-col items-center justify-center'>
    <button className='bg-blue-500 text-white p-2 rounded-lg mb-4' onClick={startAudioCapture} >Record Audio</button>
    <button className='bg-blue-500 text-white p-2 rounded-lg mb-4' onClick = {stopAudioCapture} >Stop Record</button>
    <button className='bg-blue-500 text-white p-2 rounded-lg mb-4' onClick = {playMostRecentRecording}>PlayBack</button>
    <button className='bg-blue-500 text-white p-2 rounded-lg mb-4' onClick = {functionTest}>click me</button>
    <audio ref={audioRef} controls />
      </div>
    
  )
}

export default Audiotranslator
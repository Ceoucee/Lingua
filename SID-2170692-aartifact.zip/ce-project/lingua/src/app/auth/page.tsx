import React from 'react'

const Page = () => {
  return (
    <div></div>
  )
}

export default Page
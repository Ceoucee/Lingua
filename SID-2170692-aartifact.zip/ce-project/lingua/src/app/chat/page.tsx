import React from 'react'
import Recorder from '../Components/Recorder'

const ChatPage = () => {
  return (
    <div className = "w-screen h-screen ">
      <Recorder />
    </div>
  )
}

export default ChatPage